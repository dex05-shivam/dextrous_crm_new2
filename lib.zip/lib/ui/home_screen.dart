import 'dart:async';
import 'dart:convert';

import 'package:battery/battery.dart';
import 'package:dextrous_crm_new2/drawer_ui/menu_page.dart';
import 'package:dextrous_crm_new2/drawer_ui/zoom_scaffold.dart';
import 'package:dextrous_crm_new2/ui/profile_page.dart';
import 'package:dextrous_crm_new2/ui/task_list.dart';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:geolocator/geolocator.dart';

import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../liquid_progress_indicator.dart';
import 'add_expense.dart';
import 'expense_list.dart';
//import 'package:location/location.dart';
import 'lead_screen.dart';
void main() => runApp(new HomePage());

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      title: 'Dextrous Crm',
      debugShowCheckedModeBanner: false,
      theme: new ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: new MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => new _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> with TickerProviderStateMixin {
  MenuController menuController;
  DateTime currentBackPressTime;
//  var location = new Location();
  String lat='',long='',battery1='',email='',name='',total_leads='',finished_total_leads='',
      total_tasks='',finished_total_tasks='',performance='';
  SharedPreferences prefs;
//  Future<Map<String, double>> _getLocation() async {
//    var currentLocation = <String, double>{};
//    try {
//      currentLocation = await location.getLocation();
//    } catch (e) {
//      currentLocation = null;
//    }
//    battery1 = await battery.batteryLevel.toString();
//    print(await battery.batteryLevel);
//    return currentLocation;
//  }
  // Map<String, double> userLocation;
  var battery = Battery();
  Future<bool> _onBackPressed() {


    return Future.value(true);

  }
  @override
  void initState() {
    super.initState();

    menuController = new MenuController(
      vsync: this,
    )..addListener(() => setState(() {}));

//    _getLocation().then((value) {
//      setState(() {
//        userLocation = value;
//        lat=userLocation["latitude"].toString();
//        long=userLocation["longitude"].toString();
//      });
//    });

    new Timer.periodic(Duration(seconds: 60), (Timer t) => setState((){getToekn();}));

    getToekn();
  }
  bool isResponse= false;
  var performanceDouble;


  Future<int> getToekn() async {
    prefs = await SharedPreferences.getInstance();
    name=prefs.getString('name');
    email=prefs.getString('email');
    total_tasks=prefs.getString('total_tasks');
    finished_total_leads=prefs.getString('finished_total_leads');
    total_leads=prefs.getString('total_leads');
    performance=prefs.getString('performance');
    finished_total_tasks=prefs.getString('finished_total_tasks');
    performanceDouble = double.parse(performance)/100;

    assert(performanceDouble is double);
    print(performanceDouble);
    //email=prefs.getString('email');
    var now = new DateTime.now();

    var geolocator = Geolocator();
    var locationOptions = LocationOptions(accuracy: LocationAccuracy.high, distanceFilter: 10);

    StreamSubscription<Position> positionStream = geolocator.getPositionStream(locationOptions).listen(
            (Position position) {
          lat=position.latitude.toString();
          long =position.longitude.toString();
          print(position == null ? 'Unknown' : position.latitude.toString() + ', ' + position.longitude.toString());
        });
    String date1=now.year.toString()+'-'+now.month.toString()+'-'+now.day.toString();
    // String login_url = "http://ems.dextrousinfosolutions.com/dev-dexcrm/api/auth/tracking";
    FormData formData = new FormData.from({
      "date": date1,
      "userId":prefs.getString('userId'),
      "token": prefs.getString('user_token'),
      "longitude" : long,
      "latitude" : lat,
      "batteryPer" : battery1,

    });
    print(lat + long);

    http.Response response = await http.post("http://ems.dextrousinfosolutions.com/dev-dexcrm/api/auth/tracking", body: formData);


    setState(() {

      isResponse=true;

    });
    var body = await json.decode(response.body);
    if(response.statusCode==200){
      print(response.body);


      isResponse=false;

    }else{
      isResponse=true;
    }
    //Simulate a service call
    print('submitting to backend...');
    new Future.delayed(new Duration(seconds: 4), () {



    });


//    prefs.setString('main_token',body['token'] );
//    print(body['token']);
    return body['status'];
  }

  @override
  void dispose() {
    menuController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final deviceRatio = size.width;
    return ChangeNotifierProvider(
      builder: (context) => menuController,
      child: WillPopScope(
        onWillPop: _onBackPressed,
        child:ZoomScaffold(
          menuScreen: MenuScreenState(),
          contentScreen: Layout(
              contentBuilder: (cc) => Container(
                child:  Expanded(
                  child: Container(
                    child: ListView(
                      shrinkWrap: true,
                      children: <Widget>[
                        Padding(
                          padding:
                          const EdgeInsets.fromLTRB(20.0, 50, 20, 20),
                          child: Card(
                            child: Container(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Padding(
                                    padding: const EdgeInsets.fromLTRB(
                                        15.0, 10, 10, 0),
                                    child: Row(
                                      mainAxisAlignment:
                                      MainAxisAlignment.start,
                                      crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                      children: <Widget>[
                                        Padding(
                                          padding: const EdgeInsets.all(4.0),
                                          child: Column(
                                            mainAxisAlignment:
                                            MainAxisAlignment.start,
                                            crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                            children: <Widget>[
                                              Text(
                                                'Analystic Overview',
                                                style: TextStyle(
                                                  color: Colors.grey[800],
                                                  fontSize: 15,
                                                ),
                                              ),
                                              Padding(
                                                padding: const EdgeInsets.fromLTRB(0,5,0,0),
                                                child: Text(
                                                  ["", null, false, 0].contains(name)?name :name,
                                                  style: TextStyle(
                                                      color: Colors.grey[800],
                                                      fontSize: 14,
                                                      fontWeight: FontWeight.w700
                                                  ),
                                                ),
                                              ),
                                              Text(
                                                ["", null, false, 0].contains(email)?email :email,
                                                style: TextStyle(
                                                  color: Colors.grey[500],
                                                  fontSize: 12,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          height: 35,
                                          width: 35,
                                          child:
                                          LiquidCircularProgressIndicator(
                                            value: performanceDouble, // Defaults to 0.5.
                                            valueColor:
                                            AlwaysStoppedAnimation(Colors
                                                .blue[
                                            900]), // Defaults to the current Theme's accentColor.
                                            backgroundColor: Colors
                                                .white, // Defaults to the current Theme's backgroundColor.
                                            borderColor: Colors.blue[400],
                                            borderWidth: 5.0,
                                            direction: Axis
                                                .vertical, // The direction the liquid moves (Axis.vertical = bottom to top, Axis.horizontal = left to right). Defaults to Axis.vertical.
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.fromLTRB(
                                        10.0, 30, 10, 10),
                                    child: Row(
                                      crossAxisAlignment:
                                      CrossAxisAlignment.center,
                                      mainAxisAlignment:
                                      MainAxisAlignment.center,
                                      children: <Widget>[
                                        Flexible(
                                          child: Card(
                                            child:  Container(
                                              child: Column(

                                                children: <Widget>[
                                                  Center(
                                                    child: Text(["", null, false].contains(finished_total_leads) ? ["", null, false].contains(total_leads) ? finished_total_leads+'/'+total_leads : "0/0" : finished_total_leads+'/'+total_leads,style: TextStyle(
                                                        color: Colors.black87,
                                                        fontSize: 15,
                                                        fontWeight: FontWeight.w900
                                                    )),
                                                  ),
                                                  Padding(
                                                    padding: const EdgeInsets.fromLTRB(0,5,0,0),
                                                    child: Text('Leads Status',style: TextStyle(
                                                        color: Colors.blue,
                                                        fontSize: 12,
                                                        fontWeight: FontWeight.w700
                                                    )),
                                                  ),

                                                ],
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                              ),
                                              width: 100,
                                              height: 60,
                                              decoration: BoxDecoration(
                                                color: Colors.white,
                                                borderRadius:
                                                BorderRadius.circular(
                                                    8.0),
                                              ),
                                            ),
                                            elevation: 5,
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                              BorderRadius.circular(8.0),
                                            ),

                                          ),
                                          flex: 1,
                                        ),
                                        Flexible(
                                          child: Card(
                                            child: Container(
                                              child: Center(child: Column(
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: <Widget>[
                                                  Center(
                                                    child: Text(["", null, false].contains(finished_total_tasks) ? ["", null, false].contains(total_tasks) ? finished_total_tasks+'/'+total_tasks: '0/0' : finished_total_tasks+'/'+total_tasks,style: TextStyle(
                                                        color: Colors.black87,
                                                        fontSize: 15,
                                                        fontWeight: FontWeight.w900
                                                    )),
                                                  ),
                                                  Padding(
                                                    padding: const EdgeInsets.fromLTRB(0,5,0,0),
                                                    child: Text('Task Status',style: TextStyle(
                                                        color: Colors.blue,
                                                        fontSize: 12,
                                                        fontWeight: FontWeight.w900
                                                    )),
                                                  ),
                                                ],
                                              )),
                                              width: 100,
                                              height: 60,
                                              decoration: BoxDecoration(
                                                color: Colors.white,
                                                borderRadius:
                                                BorderRadius.circular(
                                                    8.0),
                                              ),
                                            ),
                                            elevation: 5,
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                              BorderRadius.circular(8.0),
                                            ),
                                          ),
                                          flex: 1,
                                        ),
                                        Flexible(
                                          child: Card(
                                            child: Container(
                                              child:  Center(child: Column(
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: <Widget>[
                                                  Center(
                                                    child: Text(["", null, false].contains(performance) ?'0%' : performance+'%',style: TextStyle(
                                                        color: Colors.black87,
                                                        fontSize: 15,
                                                        fontWeight: FontWeight.w900
                                                    )),
                                                  ),
                                                  Padding(
                                                    padding: const EdgeInsets.fromLTRB(0,5,0,0),
                                                    child: Text('Performance',style: TextStyle(
                                                        color: Colors.blue,
                                                        fontSize: 12,
                                                        fontWeight: FontWeight.w900
                                                    )),
                                                  ),
                                                ],
                                              )),
                                              width: 100,
                                              height: 60,
                                              decoration: BoxDecoration(
                                                color: Colors.white,
                                                borderRadius:
                                                BorderRadius.circular(
                                                    8.0),
                                              ),
                                            ),
                                            elevation: 5,
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                              BorderRadius.circular(8.0),
                                            ),
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    ),
                                  )
                                ],
                              ),
                              height: 180,
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  image: AssetImage(
                                      "assets/images/background.png"),
                                  fit: BoxFit.fill,
                                ),
                                borderRadius: BorderRadius.circular(15.0),
                              ),
                              width: deviceRatio,
                            ),
                            elevation: 10,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15.0),
                            ),
                          ),
                        ),
                        Padding(
                            padding:
                            const EdgeInsets.fromLTRB(20.0, 20, 20, 20),
                            child: Container(
                                alignment: Alignment.center,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment:
                                  CrossAxisAlignment.center,
                                  children: <Widget>[
                                    Row(
                                      mainAxisAlignment:
                                      MainAxisAlignment.center,
                                      crossAxisAlignment:
                                      CrossAxisAlignment.center,
                                      children: <Widget>[
                                        Flexible(
                                          child:GestureDetector(
                                            onTap: () {
                                              Navigator.of(context).push(MaterialPageRoute<Null>(
                                                  builder: (BuildContext context) {
                                                    return new TaskList();
                                                  }));
                                            },
                                            child: Card(
                                              color: Colors.white,
                                              child: Center(
                                                child: Container(
                                                  child: Column(
                                                      mainAxisAlignment: MainAxisAlignment.center,
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: <Widget>[

                                                        Padding(
                                                          padding: const EdgeInsets.fromLTRB(0,0,0,0),
                                                          child: Center(
                                                            child: Text(
                                                              'Tasks',
                                                              style: TextStyle(
                                                                  color: Colors.black,
                                                                  fontSize: 15,
                                                                  fontWeight: FontWeight.w900
                                                              ),

                                                            ),
                                                          ),
                                                        )


                                                      ]),
                                                  height: 100,

                                                  decoration: BoxDecoration(
                                                    image: DecorationImage(
                                                      image: AssetImage(
                                                          "assets/images/b.png"),
                                                      fit: BoxFit.fill,
                                                    ),
                                                    borderRadius:
                                                    BorderRadius.circular(
                                                        8.0),
                                                  ),
                                                ),
                                              ),
                                              shape: RoundedRectangleBorder(
                                                borderRadius:
                                                BorderRadius.circular(8.0),
                                              ),
                                              elevation: 10,
                                            ),),
                                          flex: 1,
                                        ),
//                                          Flexible(
//                                            child: Card(
//                                              color: Colors.white,
//                                              child: Center(
//                                                child: Container(
//                                                  child: Column(
//                                                      mainAxisSize:
//                                                          MainAxisSize.min,
//                                                      crossAxisAlignment:
//                                                          CrossAxisAlignment
//                                                              .center,
//                                                      mainAxisAlignment: MainAxisAlignment.center,
//                                                      children: <Widget>[
//                                                        Padding(
//                                                          padding: const EdgeInsets.fromLTRB(0,0,0,0),
//                                                          child: Center(
//                                                            child: Text(
//                                                              'Performance',
//                                                              style: TextStyle(
//                                                                  color: Colors.black,
//                                                                  fontSize: 15,
//                                                                  fontWeight: FontWeight.w900
//                                                              ),
//
//                                                            ),
//                                                          ),
//                                                        )
//                                                      ]),
//                                                  height: 100,
//                                                  width: 100,
//                                                  decoration: BoxDecoration(
//                                                    image: DecorationImage(
//                                                      image: AssetImage(
//                                                          "assets/images/c1.png"),
//                                                      fit: BoxFit.fill,
//                                                    ),
//                                                    borderRadius:
//                                                        BorderRadius.circular(
//                                                            8.0),
//                                                  ),
//                                                ),
//                                              ),
//                                              shape: RoundedRectangleBorder(
//                                                borderRadius:
//                                                    BorderRadius.circular(8.0),
//                                              ),
//                                              elevation: 10,
//                                            ),
//                                            flex: 1,
//                                          ),
                                        Flexible(
                                          child:GestureDetector(child:   Card(
                                            color: Colors.white,
                                            child: Center(
                                              child: Container(
                                                child: Column(
                                                    mainAxisSize:
                                                    MainAxisSize.min,
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .center,
                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                    children: <Widget>[
                                                      Padding(
                                                        padding: const EdgeInsets.fromLTRB(0,0,0,0),
                                                        child: Center(
                                                          child: Text(
                                                            'Profile',
                                                            style: TextStyle(
                                                                color: Colors.black,
                                                                fontSize: 15,
                                                                fontWeight: FontWeight.w900
                                                            ),

                                                          ),
                                                        ),
                                                      )
                                                    ]),
                                                height: 100,
                                                decoration: BoxDecoration(
                                                  image: DecorationImage(
                                                    image: AssetImage(
                                                        "assets/images/d.png"),
                                                    fit: BoxFit.fill,
                                                  ),
                                                  borderRadius:
                                                  BorderRadius.circular(
                                                      8.0),
                                                ),
                                              ),
                                            ),
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                              BorderRadius.circular(8.0),
                                            ),
                                            elevation: 10,
                                          ),onTap: (){
                                            Navigator.of(context).push(MaterialPageRoute<Null>(
                                                builder: (BuildContext context) {
                                                  return new Profile();
                                                }));},),
                                          flex: 1,
                                        ),

                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                      MainAxisAlignment.center,
                                      crossAxisAlignment:
                                      CrossAxisAlignment.center,
                                      children: <Widget>[
                                        Flexible(child:
                                        GestureDetector(
                                          onTap: () {
                                            Navigator.of(context).push(MaterialPageRoute<Null>(
                                                builder: (BuildContext context) {
                                                  return new LeadScreen();
                                                }));
                                          },
                                          child: Card(
                                            color: Colors.white,
                                            child: Center(
                                              child: Container(
                                                child: Column(
                                                    mainAxisSize:
                                                    MainAxisSize.min,
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .center,
                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                    children: <Widget>[
                                                      Padding(
                                                        padding: const EdgeInsets.fromLTRB(0,0,0,0),
                                                        child: Center(
                                                          child: Text(
                                                            'Leads',
                                                            style: TextStyle(
                                                                color: Colors.black,
                                                                fontSize: 15,
                                                                fontWeight: FontWeight.w900
                                                            ),

                                                          ),
                                                        ),
                                                      )
                                                    ]),
                                                height: 100,
                                                decoration: BoxDecoration(
                                                  image: DecorationImage(
                                                    image: AssetImage(
                                                        "assets/images/e.png"),
                                                    fit: BoxFit.fill,
                                                  ),
                                                  borderRadius:
                                                  BorderRadius.circular(
                                                      8.0),
                                                ),
                                              ),
                                            ),
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                              BorderRadius.circular(8.0),
                                            ),
                                            elevation: 10,
                                          ),
                                        ),
                                          flex: 1,
                                        ),
                                        Flexible(
                                          child: GestureDetector(
                                            onTap: () {
                                              Navigator.of(context).push(MaterialPageRoute<Null>(
                                                  builder: (BuildContext context) {
                                                    return new ExpenseLis();
                                                  }));
                                            },
                                            child: Card(
                                              color: Colors.white,
                                              child: Center(
                                                child: Container(
                                                  child: Column(
                                                      mainAxisSize:
                                                      MainAxisSize.min,
                                                      crossAxisAlignment:
                                                      CrossAxisAlignment
                                                          .center,
                                                      mainAxisAlignment: MainAxisAlignment.center,
                                                      children: <Widget>[
                                                        Padding(
                                                          padding: const EdgeInsets.fromLTRB(0,0,0,0),
                                                          child: Center(
                                                            child: Text(
                                                              'Expence',
                                                              style: TextStyle(
                                                                  color: Colors.black,
                                                                  fontSize: 15,
                                                                  fontWeight: FontWeight.w900
                                                              ),

                                                            ),
                                                          ),
                                                        )
                                                      ]),
                                                  height: 100,

                                                  decoration: BoxDecoration(
                                                    image: DecorationImage(
                                                      image: AssetImage(
                                                          "assets/images/f.png"),
                                                      fit: BoxFit.fill,
                                                    ),
                                                    borderRadius:
                                                    BorderRadius.circular(
                                                        8.0),
                                                  ),
                                                ),
                                              ),
                                              shape: RoundedRectangleBorder(
                                                borderRadius:
                                                BorderRadius.circular(8.0),
                                              ),
                                              elevation: 10,
                                            ),),
                                          flex: 1,
                                        ),
//                                          Flexible(
//                                            child: Card(
//                                              color: Colors.white,
//                                              child: Center(
//                                                child: Container(
//                                                  child: Column(
//                                                      mainAxisSize:
//                                                          MainAxisSize.min,
//                                                      crossAxisAlignment:
//                                                          CrossAxisAlignment
//                                                              .center,
//                                                      mainAxisAlignment: MainAxisAlignment.center,
//                                                      children: <Widget>[
//                                                        Padding(
//                                                          padding: const EdgeInsets.fromLTRB(0,0,0,0),
//                                                          child: Center(
//                                                            child: Text(
//                                                              'Orders',
//                                                              style: TextStyle(
//                                                                  color: Colors.black,
//                                                                  fontSize: 15,
//                                                                  fontWeight: FontWeight.w900
//                                                              ),
//
//                                                            ),
//                                                          ),
//                                                        )
//                                                      ]),
//                                                  height: 100,
//                                                  width: 100,
//                                                  decoration: BoxDecoration(
//                                                    image: DecorationImage(
//                                                      image: AssetImage(
//                                                          "assets/images/g.png"),
//                                                      fit: BoxFit.fill,
//                                                    ),
//                                                    borderRadius:
//                                                        BorderRadius.circular(
//                                                            8.0),
//                                                  ),
//                                                ),
//                                              ),
//                                              shape: RoundedRectangleBorder(
//                                                borderRadius:
//                                                    BorderRadius.circular(8.0),
//                                              ),
//                                              elevation: 10,
//                                            ),
//                                            flex: 1,
//                                          )
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                      MainAxisAlignment.center,
                                      crossAxisAlignment:
                                      CrossAxisAlignment.center,
                                      children: <Widget>[
                                        Flexible(
                                          child: Card(
                                            color: Colors.white,
                                            child: Center(
                                              child: Container(
                                                child: Column(
                                                    mainAxisSize:
                                                    MainAxisSize.min,
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .center,
                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                    children: <Widget>[
                                                      Padding(
                                                        padding: const EdgeInsets.fromLTRB(0,0,0,0),
                                                        child: Center(
                                                          child: Text(
                                                            'Utilities',
                                                            style: TextStyle(
                                                                color: Colors.black,
                                                                fontSize: 15,
                                                                fontWeight: FontWeight.w900
                                                            ),

                                                          ),
                                                        ),
                                                      )
                                                    ]),
                                                height: 100,
                                                decoration: BoxDecoration(
                                                  image: DecorationImage(
                                                    image: AssetImage(
                                                        "assets/images/h.png"),
                                                    fit: BoxFit.fill,
                                                  ),
                                                  borderRadius:
                                                  BorderRadius.circular(
                                                      8.0),
                                                ),
                                              ),
                                            ),
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                              BorderRadius.circular(8.0),
                                            ),
                                            elevation: 10,
                                          ),
                                          flex: 1,
                                        ),
                                        Flexible(
                                          child: Card(
                                            color: Colors.white,
                                            child: Center(
                                              child: Container(
                                                child: Column(
                                                    mainAxisSize:
                                                    MainAxisSize.min,
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .center,
                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                    children: <Widget>[Padding(
                                                      padding: const EdgeInsets.fromLTRB(0,0,0,0),
                                                      child: Center(
                                                        child: Text(
                                                          'Support',
                                                          style: TextStyle(
                                                              color: Colors.black,
                                                              fontSize: 15,
                                                              fontWeight: FontWeight.w900
                                                          ),

                                                        ),
                                                      ),
                                                    )]),
                                                height: 100,
                                                decoration: BoxDecoration(
                                                  image: DecorationImage(
                                                    image: AssetImage(
                                                        "assets/images/i.png"),
                                                    fit: BoxFit.fill,
                                                  ),
                                                  borderRadius:
                                                  BorderRadius.circular(
                                                      8.0),
                                                ),
                                              ),
                                            ),
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                              BorderRadius.circular(8.0),
                                            ),
                                            elevation: 10,
                                          ),
                                          flex: 1,
                                        ),
//                                          Flexible(
//                                            child: Card(
//                                              color: Colors.white,
//                                              child: Center(
//                                                child: Container(
//                                                  child: Column(
//                                                      mainAxisSize:
//                                                          MainAxisSize.min,
//                                                      crossAxisAlignment:
//                                                          CrossAxisAlignment
//                                                              .center,
//                                                      mainAxisAlignment: MainAxisAlignment.center,
//                                                      children: <Widget>[
//                                                        Padding(
//                                                          padding: const EdgeInsets.fromLTRB(0,0,0,0),
//                                                          child: Center(
//                                                            child: Text(
//                                                              'Notes',
//                                                              style: TextStyle(
//                                                                  color: Colors.black,
//                                                                  fontSize: 15,
//                                                                  fontWeight: FontWeight.w900
//                                                              ),
//
//                                                            ),
//                                                          ),
//                                                        )
//                                                      ]),
//                                                  height: 100,
//                                                  width: 100,
//                                                  decoration: BoxDecoration(
//                                                    image: DecorationImage(
//                                                      image: AssetImage(
//                                                          "assets/images/k.png"),
//                                                      fit: BoxFit.fill,
//                                                    ),
//                                                    borderRadius:
//                                                        BorderRadius.circular(
//                                                            8.0),
//                                                  ),
//                                                ),
//                                              ),
//                                              shape: RoundedRectangleBorder(
//                                                borderRadius:
//                                                    BorderRadius.circular(8.0),
//                                              ),
//                                              elevation: 10,
//                                            ),
//                                            flex: 1,
//                                          )
                                      ],
                                    )
                                  ],
                                ))),
                      ],
                    ),
                  ),
                ),
              )),
        ),),
    );
  }
}

class DashboardModel {
  const DashboardModel({this.title, this.icon});

  final String title;
  final IconData icon;
}

const List<DashboardModel> choices = const <DashboardModel>[
  const DashboardModel(title: 'Car', icon: Icons.directions_car),
  const DashboardModel(title: 'Bicycle', icon: Icons.directions_bike),
  const DashboardModel(title: 'Boat', icon: Icons.directions_boat),
];

class DashboardCard extends StatelessWidget {
  const DashboardCard({Key key, this.choice}) : super(key: key);
  final DashboardModel choice;

  @override
  Widget build(BuildContext context) {
    final TextStyle textStyle = Theme.of(context).textTheme.display1;
    return Card(
        color: Colors.white,
        child: Center(
          child: Container(
            child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                      child: Icon(choice.icon,
                          size: 90.0, color: textStyle.color)),
                  Text(choice.title, style: textStyle),
                ]),
            height: 150,
            width: 150,
          ),
        ));
  }
}