import 'package:dextrous_crm_new2/conts/config.dart';
import 'package:dextrous_crm_new2/ui/view_task.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'add_expense.dart';
import 'home_screen.dart';
import 'leads_details.dart';


class TaskList extends StatefulWidget {
  @override
  _TaskListState createState() => new _TaskListState();
}

class _TaskListState extends State<TaskList> {
  final String uri =
      "http://ems.dextrousinfosolutions.com/dev-dexcrm/api/tasks/taskList";

  bool isHomeDataLoading;

  String leads_tab="assets/images/leads1.png",status_tab="assets/images/status.png";

  int countValue=0;


  Future<List<Leads>> getToekn(String type) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    String login_url =
        "http://ems.dextrousinfosolutions.com/dev-dexcrm/api/tasks/taskList";
    FormData formData = new FormData.from({
      "userId": '2',
      "token": '55cf20552bd5ee24b49ed65bd69989a0',
    });

    http.Response response = await http.post(login_url, body: formData);

    print(response.body);

    var body = await json.decode(response.body);
    //Simulate a service call
    print('submitting to backend...');
    Map<String, dynamic> decodedMap = jsonDecode(response.body);

    try {
      if (response.statusCode == 200) {
        print(response.body);
        List<dynamic> dynamicList = decodedMap['taskList'];
        List<Leads> students = new List<Leads>();
        dynamicList.forEach((f) {
          Leads s = Leads.fromJson(f);
          students.add(s);
        });
        return students;
      } else {
        throw Exception(MESSAGES.INTERNET_ERROR);
      }
    } catch (e) {
      throw Exception(e);
    }
//    prefs.setString('main_token',body['token'] );
//    print(body['token']);
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getToekn('1');
    isHomeDataLoading = false;
  }

  setLoading(bool loading) {
    setState(() {
      isHomeDataLoading = loading;
    });
  }

  fetch() {
    setLoading(true);
  }

  Future<bool> _onBackPressed() {
    return
      Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) =>
                MyHomePage(

                ),
          ));
  }
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Scaffold(
        body: WillPopScope(
        onWillPop: _onBackPressed,
        child:new Container(
            child: new Stack(
              children: <Widget>[
                Image.asset(
                  'assets/images/backgrounddashboard.png',
                  fit: BoxFit.cover,
                  height: double.infinity,
                  width: size.width,
                ),
                Column(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0, 30, 0, 0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          new IconButton(
                              icon: Icon(
                                Icons.arrow_back,
                                color: Colors.white,
                                size: 20,
                              ),
                              onPressed: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) =>
                                          MyHomePage(

                                          ),
                                    ));
                              }),
                          Flexible(
                            child: Center(
                              child: Text(
                                'Task List',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 20,
                                ),
                              ),
                            ),
                            flex: 1,
                          ),
//                          Flexible(
//
//                            child: Padding(
//                                padding: const EdgeInsets.fromLTRB(8.0,0,10,0),
//                                child: GestureDetector(child: Text(
//                                  'View Task',
//                                  style: TextStyle(
//                                    color: Colors.white,
//                                    fontSize: 10,
//                                    decoration: TextDecoration.underline,
//                                  ),
//
//                                ),onTap: (){
//                                  Navigator.of(context).push(MaterialPageRoute<Null>(
//                                      builder: (BuildContext context) {
//                                        return new AddExpense();
//                                      }));
//                                },)
//                            ),
//                            flex: 0,
//                          ),
                        ],
                      ),
                    ),

//                    Padding(
//                      padding: const EdgeInsets.fromLTRB(40.0, 40, 40, 0),
//                      child: Row(
//                        mainAxisAlignment: MainAxisAlignment.center,
//                        crossAxisAlignment: CrossAxisAlignment.start,
//                        children: <Widget>[
//                          Flexible( child:GestureDetector(
//                            onTap: () {
//                              setState(() {
//
//                                leads_tab="assets/images/leads1.png";
//                                status_tab="assets/images/status.png";
//                                countValue=1;
//                                getToekn('1');
//
//                              }  );
////                Navigator.push(
////                  context,
////                  MaterialPageRoute(builder: (context) => ForgotPasswordApp()),
////                );
//                            },
//
//                            child: new Image.asset(
//                              leads_tab,
//                              width: 100,
//                              height: 40,
//                            ),
//                          ),
//                            flex: 1,
//                          ),
//                          Padding(
//                            padding: const EdgeInsets.fromLTRB(0.0,3,0,0),
//                            child: Container(
//                              color: Colors.grey,
//                              height: 27,
//                              width: 1,
//                            ),
//                          ),
//                          Flexible(
//                            child: GestureDetector(
//                              onTap: () {
//                                setState(() {
//
//                                  leads_tab="assets/images/leads2.png";
//                                  status_tab="assets/images/status_click.png";
//                                  countValue=0;
//                                  getToekn('2');
//
//                                }  );
////                Navigator.push(
////                  context,
////                  MaterialPageRoute(builder: (context) => ForgotPasswordApp()),
////                );
//                              },
//                              child: new Image.asset(
//                                status_tab,
//                                width: 100,
//                                height: 40,
//                              ),
//
//                            ),
//                            flex: 1,
//                          ),
//                        ],
//                      ),
//                    ),

                    Flexible(
                      child: FutureBuilder<List<Leads>>(
                        future: getToekn('1'),
                        builder: (context, snapshot) {
                          return snapshot.connectionState == ConnectionState.done
                              ? snapshot.hasData
                              ? _LeadsCellState.homeGrid(snapshot, context)
                              : _LeadsCellState.retryButton(fetch)
                              : _LeadsCellState.circularProgress();
                        },
                      ),
                    ),
                  ],
                ),
              ],
            )),),
        resizeToAvoidBottomPadding: true);
  }
}

class Leads {
  String id;
  String name;
  String priority;
  String task_status, startdate, duedate;

  Leads({
    this.id,
    this.name,
    this.priority,
    this.task_status,
    this.startdate,
    this.duedate,
  });

  factory Leads.fromJson(Map<String, dynamic> json) {
    return Leads(
      id: json['id'],
      name: json['name'],
      priority: json['priority'],
      task_status: json['task_status'],
      startdate: json['startdate'],
      duedate: json['duedate'],
//      expense_name: json['expense_name'],
//      date: json['date'],
//      time: json['time'],
//      category_name: json['category_name'],
    );
  }
}

class LeadsCell extends StatefulWidget {
  int countValue = 0;
  LeadsCell(this.cellModel);
  @required
  final Leads cellModel;

  @override
  _LeadsCellState createState() => _LeadsCellState(this.cellModel);
}

class _LeadsCellState extends State<LeadsCell> {
  int countValue = 0;
  _LeadsCellState(this.cellModel);
  @required
  final Leads cellModel;

  static Container homeGrid(AsyncSnapshot<List<Leads>> snapshot, context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      height: size.height ,
      width: double.infinity,
      child: ListView.builder(
        shrinkWrap: true,
        itemCount: snapshot.data.length,
        itemBuilder: (BuildContext context, int index) {
          return LeadsCell(
            snapshot.data[index],
          );
        },
      ),
    );
  }

  static SizedBox circularProgress() {
    return SizedBox(
      height: 50.0,
      width: 50.0,
      child: CircularProgressIndicator(
        valueColor: new AlwaysStoppedAnimation<Color>(COLORS.APP_THEME_COLOR),
      ),
    );
  }

  static FlatButton retryButton(Function fetch) {
    return FlatButton(
      child: Text(
        MESSAGES.INTERNET_ERROR_RETRY,
        textAlign: TextAlign.center,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(fontWeight: FontWeight.normal),
      ),
      onPressed: () => fetch(),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Color color2 = HexColor(cellModel.color);
    return GestureDetector(
      child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Stack(children: <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(18.0,10,18,0),
              child: Card(elevation: 10,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(18.0),
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                        color: Colors.grey[300],
                        borderRadius: new BorderRadius.circular(18.0)),height: 90,)
              ),
            ),
            Card(
              elevation: 10,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16.0),
              ),
              child: Container(
                decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage("assets/images/back.png"),
                      fit: BoxFit.fill,

                    ),

                    borderRadius: new BorderRadius.circular(16.0)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[

                    Flexible(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(18.0,5,5,5),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Row(
                              children: <Widget>[
                                Expanded(child:Padding(
                                  padding: const EdgeInsets.fromLTRB(0, 5.0, 0, 0),
                                  child: Text(
                                    cellModel.name,
                                    style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.w400,
                                    ),
                                  ),
                                ) ,flex: 1,)

                              ],
                            ),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                Expanded(child: Padding(
                                  padding: const EdgeInsets.fromLTRB(4.0, 5, 5, 0),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: <Widget>[
                                      Text('Priority: ',
                                          style: TextStyle(
                                              fontSize: 13,
                                              fontWeight: FontWeight.w700,
                                              color: Colors.grey)),
                                      Text(cellModel.priority,
                                          style: TextStyle(
                                              fontSize: 13,
                                              fontWeight: FontWeight.w600,
                                              color: Colors.grey[800])),

                                    ],
                                  ),
                                ),flex: 1,)
                                ,
                                Expanded(child: Padding(
                                  padding: const EdgeInsets.fromLTRB(4.0, 5, 5, 0),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: <Widget>[
                                      Text('Status: ',
                                          style: TextStyle(
                                              fontSize: 13,
                                              fontWeight: FontWeight.w700,
                                              color: Colors.grey)),
                                      Padding(
                                        padding: const EdgeInsets.fromLTRB(0, 0, 0, 5),
                                        child: Text(
                                          cellModel.task_status,
                                          style: TextStyle(
                                            fontSize: 13,
                                            fontWeight: FontWeight.w700,
                                          ),
                                        ),
                                      ),

                                    ],
                                  ),
                                ),flex: 1,)

                              ],
                            ),
                            Row(
                              children: <Widget>[
                                Expanded(child:
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(5,5,0,0),
                                  child: Row(
                                    children: <Widget>[
                                      Text("Start Date:" ,
                                          style: TextStyle(
                                              fontSize: 10,
                                              fontWeight: FontWeight.w700,
                                              color: Colors.grey)),

                                      Padding(
                                        padding: const EdgeInsets.fromLTRB(4.0,0,0,0),
                                        child: Text(cellModel.startdate,
                                            style: TextStyle(
                                                fontSize: 12,
                                                fontWeight: FontWeight.w500,
                                                color: Colors.black)),
                                      ),

                                    ],
                                  ),
                                ),flex: 1,),

                                Expanded(child:Padding(
                                  padding: const EdgeInsets.fromLTRB(10,5,0,0),
                                  child: Row(
                                    children: <Widget>[

                                      Text("Due Date:" ,
                                          style: TextStyle(
                                              fontSize: 10,
                                              fontWeight: FontWeight.w700,
                                              color: Colors.grey)),

                                      Padding(
                                        padding: const EdgeInsets.fromLTRB(4.0,0,0,0),
                                        child: Text(cellModel.duedate ,
                                            style: TextStyle(
                                                fontSize: 12,
                                                fontWeight: FontWeight.w500,
                                                color: Colors.black)),
                                      ),
                                    ],
                                  ),
                                ),flex: 1,),
                Padding(
                  padding: const EdgeInsets.fromLTRB(5.0,5,0,5),
                  child: Icon(Icons.attachment),
                )
                              ],
                            ),

                          ],
                        ),
                      ),
                      flex: 2,
                      fit: FlexFit.tight,
                    ),

                  ],
                ),
              ),
            )
          ],)
      ),
      onTap: () {
        // setState(() => countValue == 0 ? countValue = 1 : countValue = 0);
        // Grid Click

        Navigator.of(context).push(MaterialPageRoute<Null>(
            builder: (BuildContext context) {
              return new TaskDetails(text: cellModel.id,);
            }));
      },
    );
  }
}

class HexColor extends Color {
  static int _getColorFromHex(String hexColor) {
    hexColor = hexColor.toUpperCase().replaceAll("#", "");
    if (hexColor.length == 6) {
      hexColor = "FF" + hexColor;
    }
    return int.parse(hexColor, radix: 16);
  }

  HexColor(final String hexColor) : super(_getColorFromHex(hexColor));
}
