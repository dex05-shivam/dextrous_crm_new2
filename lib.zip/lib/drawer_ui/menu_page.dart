
import 'package:dextrous_crm_new2/drawer_ui/zoom_scaffold.dart';
import 'package:dextrous_crm_new2/ui/expense_list.dart';
import 'package:dextrous_crm_new2/ui/lead_screen.dart';
import 'package:dextrous_crm_new2/ui/login_page.dart';
import 'package:dextrous_crm_new2/ui/profile_page.dart';
import 'package:dextrous_crm_new2/ui/task_list.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'circular_image.dart';

class MenuScreenState extends StatefulWidget {



  @override
  MenuScreen createState() => new MenuScreen();
}


class MenuScreen extends  State<MenuScreenState> {
  String imageUrl ='';
  DateTime currentBackPressTime;
  final List<MenuItem> options = [
    MenuItem(Image.asset('assets/images/home.png',height: 20,width: 20,), 'Home'),
    MenuItem(Image.asset('assets/images/task.png',height: 20,width: 20,), 'Task'),
    //MenuItem(Image.asset('assets/images/performance.png',height: 20,width: 20,), 'Performance'),
    MenuItem(Image.asset('assets/images/profile.png',height: 20,width: 20,), 'Profile'),
    MenuItem(Image.asset('assets/images/leads.png',height: 20,width: 20,), 'Lead'),
    MenuItem(Image.asset('assets/images/expense.png',height: 20,width: 20,), 'Expense'),
    //MenuItem(Image.asset('assets/images/order.png',height: 20,width: 20,), 'Order'),
   // MenuItem(Image.asset('assets/images/utility.png',height: 20,width: 20,), 'Utilities'),
  ];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getHearderValue();

  }
  String name='',email='not available',pic='';


  Future<bool> _onBackPressed() {

    return Future.value(true);
  }

  getHearderValue() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    name=prefs.getString('name');
    email=prefs.getString('email');
    imageUrl=prefs.getString('profile');
   // name=prefs.getString('name');
   // name=prefs.getString('name');
  }

  @override
  Widget build(BuildContext context) {

    return GestureDetector(
      onPanUpdate: (details) {
        //on swiping left
        if (details.delta.dx < -6) {
          Provider.of<MenuController>(context, listen: true).toggle();
        }
      },
      child:WillPopScope(
      onWillPop: _onBackPressed,
      child: Container(
        padding: EdgeInsets.only(
            top: 62,
            left: 22,
            bottom: 8,
            right: MediaQuery.of(context).size.width / 4.9),
        color: Color(0xff253f5b),
        child: Column(
          children: <Widget>[
            Container(
              child: Row(
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.only(right: 16),
                    child: CircularImage(
                      NetworkImage(!["", null, false, 0].contains(imageUrl)? imageUrl :"https://huntpng.com/images250/avatar-png-1.png"),
                    ),
                  ),
                  Flexible(child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        name,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                        ),
                      ),
                      Container(
                        child: Text(
                          email,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.clip,
                        ),
                        width: 200,
                      )

                    ],
                  ),flex: 1,)
                ],
              ),
            ),
            Spacer(),
            Column(
              children: options.map((item) {
                return ListTile(
                  leading: item.icon,
                  dense: true,
                  title: Text(
                    item.title,
                    style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),
                  ),
                  onTap: (){
                    Provider.of<MenuController>(context, listen: true).toggle();
//                    Navigator.of(context).push(MaterialPageRoute<Null>(
//                        builder: (BuildContext context) {
//                          return new RegisterScreen();
//                        }));

                    if(item.title=='Home'){
                      Provider.of<MenuController>(context, listen: true).toggle();
                    }
                    if(item.title=='Task'){
                      Navigator.of(context).push(MaterialPageRoute<Null>(
                          builder: (BuildContext context) {
                            return new TaskList();
                          }));
                    }
                    if(item.title=='Profile'){
                      Navigator.of(context).push(MaterialPageRoute<Null>(
                          builder: (BuildContext context) {
                            return new Profile();
                          }));
                    }
                    if(item.title=='Lead'){
                      Navigator.of(context).push(MaterialPageRoute<Null>(
                          builder: (BuildContext context) {
                            return new LeadScreen();
                          }));
                    }
                    if(item.title=='Expense'){
                      Navigator.of(context).push(MaterialPageRoute<Null>(
                          builder: (BuildContext context) {
                            return new ExpenseLis();
                          }));
                    }
                    print(item.title);
                  },
                );
              }).toList(),
            ),
            Spacer(),
            ListTile(
              onTap: () {},
              leading: Image.asset(
                'assets/images/utility.png',
                height: 20,width: 20,
              ),
              title: Text('Utilities',
                  style: TextStyle(fontSize: 14, color: Colors.white)),
            ),
            ListTile(
              onTap: () {

              },
              leading: Image.asset(
                'assets/images/contact.png',
                height: 20,width: 20,
              ),
              title: Text('Support',
                  style: TextStyle(fontSize: 14, color: Colors.white)),
            ),

            ListTile(
              onTap: ()  async {

                SharedPreferences prefs = await SharedPreferences.getInstance();
                prefs.remove('userId');
                prefs.remove('user_token');
                prefs.remove('name');
                prefs.remove('email');
                //prefs.remove('userId');
                Navigator.of(context).pop(true);
                Navigator.of(context).push(MaterialPageRoute<Null>(
                        builder: (BuildContext context) {
                          return new LoginScreen();
                        }));
              },
              leading: Image.asset(
                'assets/images/utility.png',
                height: 20,width: 20,
              ),
              title: Text('Logout',
                  style: TextStyle(fontSize: 14, color: Colors.white)),
            ),

          ],
        ),
      ),),
    );
  }
}

class MenuItem {
  String title;
  Image icon;

  MenuItem(this.icon, this.title);
}